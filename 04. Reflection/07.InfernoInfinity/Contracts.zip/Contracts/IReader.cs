﻿namespace _07.InfernoInfinity.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
