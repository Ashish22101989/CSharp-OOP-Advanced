﻿namespace _07.InfernoInfinity.Core.Attributes
{ 
    using System;

    public class InjectAttribute : Attribute
    {
    }
}
